#pragma once
#include <stdlib.h>
#include <stdbool.h>

// ����˫�������ṹ
struct sc_list_head {
    struct sc_list_head *next, *prev;
};


#define SC_LIST_HEAD_INIT(name) { &(name), &(name) }

// ��ʼ������ͷ
static inline void SC_INIT_LIST_HEAD(struct sc_list_head *list)
{
    list->next = list;
    list->prev = list;
}

// ���½ڵ����ӵ�����β��
static inline void sc_list_add_tail(struct sc_list_head *new, struct sc_list_head *head)
{
    struct sc_list_head *prev = head->prev;
    new->next = head;
    new->prev = prev;
    prev->next = new;
    head->prev = new;
}

// ��������ɾ���ڵ�
static inline void sc_list_del(struct sc_list_head *entry)
{
    struct sc_list_head *prev = entry->prev;
    struct sc_list_head *next = entry->next;
    next->prev = prev;
    prev->next = next;
    entry->next = entry->prev = NULL;
}

#define sc_list_entry(ptr, type, member) \
    ((type *)((char *)(ptr)-(unsigned long)(&((type *)0)->member)))

#define sc_list_for_each_entry(pos, head, member) \
    for (pos = sc_list_entry((head)->next, typeof(*pos), member); \
         &pos->member != (head); \
         pos = sc_list_entry(pos->member.next, typeof(*pos), member))

// ��������Ƿ�Ϊ��
static inline bool sc_list_empty(const struct sc_list_head *head)
{
    return head->next == head;
}


#pragma once
#include "mutex.h"

void scheduler_init(void);
void scheduler_create_task(void (*func)(void*), void *arg);
void scheduler_exit_current_task(void);
void scheduler_yield(void);
void scheduler_relinquish(void);
void scheduler_run(void);
void scheduler_join(int task_id);
void scheduler_lock(mutex_t *mutex);
void scheduler_unlock(mutex_t *mutex);


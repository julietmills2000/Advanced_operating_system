#include <stdlib.h>
#include <stdio.h>
#include "scheduler.h"
#include "mutex.h"
// �����������Ĳ����ṹ
struct tester_args {
    char *name;
    int iters;
    mutex_t *mutex;
};
// ����������
void tester(void *arg)
{
    struct tester_args *ta = (struct tester_args *)arg;
    for (int i = 0; i < ta->iters; i++) {
        scheduler_lock(ta->mutex);
        printf("task %s: %d\n", ta->name, i);
        scheduler_unlock(ta->mutex);
        scheduler_relinquish();
    }
    free(ta);
    scheduler_exit_current_task();
}
// ������������
void create_test_task(char *name, int iters, mutex_t *mutex)
{
    struct tester_args *ta = malloc(sizeof(*ta));
    ta->name = name;
    ta->iters = iters;
    ta->mutex = mutex;
    scheduler_create_task(tester, ta);
}

int main(int argc, char **argv)
{
    scheduler_init();
    mutex_t print_mutex;
    mutex_init(&print_mutex);

    create_test_task("first", 5, &print_mutex);
    create_test_task("second", 2, &print_mutex);

    scheduler_run();
    printf("Finished running all tasks!\n");
    return EXIT_SUCCESS;
}

